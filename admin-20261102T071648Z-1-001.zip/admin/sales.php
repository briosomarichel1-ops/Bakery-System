<?php
session_start();
date_default_timezone_set('Asia/Manila');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

include '../conn.php';

$sales_query = "
    SELECT
        s.sale_id,
        s.receipt_number,
        s.user_id,
        s.total_amount,
        s.payment_method,
        s.transaction_no,
        s.status,
        s.created_at,
        u.fullname AS cashier_name,
        COALESCE((
            SELECT SUM(si.quantity)
            FROM sale_items si
            WHERE si.sale_id = s.sale_id
        ), 0) AS item_count
    FROM sales s
    LEFT JOIN users u
        ON s.user_id = u.user_id
    ORDER BY s.created_at DESC
";

$sales = $conn->query($sales_query);

$item_stmt = $conn->prepare("
    SELECT
        p.product_name,
        si.quantity,
        si.unit_price,
        si.subtotal
    FROM sale_items si
    LEFT JOIN products p
        ON si.product_id = p.product_id
    WHERE si.sale_id = ?
    ORDER BY si.sale_item_id ASC
");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales History | Bakery Sales & Inventory</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #75452e;
            --primary-dark: #4c2c20;
            --primary-light: #f4e9df;
            --accent: #d8894c;
            --background: #faf8f4;
            --white: #fff;
            --text: #332820;
            --muted: #95877d;
            --border: #eee7df;
            --success: #478765;
            --warning: #d99b38;
            --danger: #cf6656;
            --sidebar-width: 255px;
        }

        * {
            box-sizing: border-box
        }

        body {
            margin: 0;
            font-family: 'DM Sans', sans-serif;
            background: var(--background);
            color: var(--text);
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: var(--primary-dark);
            color: white;
            padding: 25px 18px;
            z-index: 1050;
            transition: transform .3s ease;
            overflow-y: auto;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0 10px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, .12);
            margin-bottom: 25px;
        }

        .brand-icon {
            width: 75px;
            height: 75px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            background: transparent;
        }

        .brand-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            filter:
                drop-shadow(1px 0 0 white) drop-shadow(-1px 0 0 white) drop-shadow(0 1px 0 white) drop-shadow(0 -1px 0 white);
        }

        .brand h5 {
            font-family: 'Playfair Display', serif;
            font-size: 20px;
            margin: 0;
        }

        .brand small {
            color: #c6afa0;
            font-size: 11px;
        }

        .menu-label {
            color: #aa9586;
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 1.3px;
            padding: 0 12px;
            margin: 23px 0 10px;
        }

        .sidebar .nav-link {
            display: flex;
            align-items: center;
            gap: 13px;
            color: #d9c8bd;
            padding: 11px 13px;
            border-radius: 9px;
            font-size: 13px;
            font-weight: 500;
            margin-bottom: 5px;
            transition: .2s;
        }

        .sidebar .nav-link i {
            font-size: 17px
        }

        .sidebar .nav-link:hover {
            background: rgba(255, 255, 255, .09);
            color: white;
        }

        .sidebar .nav-link.active {
            background: var(--accent);
            color: white;
            font-weight: 700;
        }

        .sidebar-footer {
            border-top: 1px solid rgba(255, 255, 255, .12);
            margin-top: 35px;
            padding: 20px 10px 0;
            color: #c6afa0;
            font-size: 11px;
        }

        .main-content {
            margin-left: var(--sidebar-width);
            padding: 25px 30px;
            min-height: 100vh;
        }

        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, .4);
            z-index: 1040;
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 30px;
            gap: 15px;
        }

        .page-title {
            font-family: 'Playfair Display', serif;
            font-size: 27px;
            font-weight: 700;
            margin: 0;
        }

        .page-subtitle {
            color: var(--muted);
            font-size: 12px;
            margin-top: 4px;
        }

        .mobile-toggle {
            display: none;
            border: 0;
            background: var(--white);
            padding: 8px 11px;
            border-radius: 8px;
            color: var(--text);
            font-size: 20px;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 18px;
        }

        .icon-button {
            width: 38px;
            height: 38px;
            border: 1px solid var(--border);
            background: white;
            border-radius: 10px;
            color: var(--text);
        }

        .profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .profile-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: var(--primary-light);
            color: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
        }

        .profile small {
            display: block;
            color: var(--muted);
            font-size: 11px;
        }

        .stat-card {
            background: white;
            border: 1px solid var(--border);
            border-radius: 13px;
            padding: 19px;
            height: 100%;
        }

        .stat-icon {
            width: 39px;
            height: 39px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 10px;
            font-size: 19px;
            margin-bottom: 13px;
        }

        .stat-label {
            color: var(--muted);
            font-size: 12px;
        }

        .stat-value {
            font-size: 25px;
            font-weight: 700;
            margin-top: 3px;
        }

        .content-card {
            background: white;
            border: 1px solid var(--border);
            border-radius: 13px;
            overflow: hidden;
        }

        .card-header-custom {
            padding: 19px 21px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }

        .card-header-custom h6 {
            font-weight: 700;
            margin: 0;
        }

        .search-box {
            position: relative;
            min-width: 220px;
        }

        .search-box i {
            position: absolute;
            left: 12px;
            top: 10px;
            color: var(--muted);
        }

        .search-box input {
            padding-left: 35px;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-size: 12px;
        }

        .form-control,
        .form-select {
            border-color: var(--border);
            font-size: 13px;
            padding: 10px 12px;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(216, 137, 76, .12);
        }

        .table {
            margin: 0;
            white-space: nowrap;
        }

        .table thead th {
            background: #fcfaf7;
            color: var(--muted);
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: .6px;
            padding: 14px 18px;
            border-bottom: 1px solid var(--border);
        }

        .table tbody td {
            padding: 15px 18px;
            font-size: 12px;
            vertical-align: middle;
            border-bottom: 1px solid #f2ede7;
        }

        .table tbody tr:last-child td {
            border-bottom: 0
        }

        .badge-status {
            padding: 6px 9px;
            border-radius: 6px;
            font-size: 10px;
            font-weight: 700;
        }

        .badge-paid {
            background: #e7f3eb;
            color: var(--success);
        }

        .badge-pending {
            background: #fff3df;
            color: #b47b22;
        }

        .badge-cancelled {
            background: #fbeae7;
            color: var(--danger);
        }

        .badge-payment {
            background: var(--primary-light);
            color: var(--primary);
            padding: 6px 9px;
            border-radius: 6px;
            font-size: 10px;
            font-weight: 700;
        }

        .text-muted-custom {
            color: var(--muted)
        }

        .action-btn {
            border: 1px solid var(--border);
            background: white;
            color: var(--muted);
            width: 31px;
            height: 31px;
            border-radius: 7px;
        }

        .action-btn:hover {
            background: var(--primary-light);
            color: var(--primary);
        }

        .btn-primary-custom {
            background: var(--primary);
            color: white;
            border: 0;
            border-radius: 8px;
            padding: 10px 16px;
            font-size: 13px;
            font-weight: 600;
        }

        .btn-primary-custom:hover {
            background: var(--primary-dark);
            color: white;
        }

        .modal-content {
            border: 0;
            border-radius: 13px;
        }

        .modal-header {
            border-bottom: 1px solid var(--border);
            padding: 20px 23px;
        }

        .modal-title {
            font-family: 'Playfair Display', serif;
            font-weight: 700;
        }

        .modal-body {
            padding: 23px
        }

        .modal-footer {
            border-top: 1px solid var(--border);
            padding: 15px 23px;
        }

        .receipt {
            border: 1px dashed #d9c9bb;
            padding: 22px;
            max-width: 380px;
            margin: auto;
            background: white;
        }

        .receipt-header {
            text-align: center;
            padding-bottom: 15px;
            border-bottom: 1px dashed #d9c9bb;
        }

        .receipt-header h4 {
            font-family: 'Playfair Display', serif;
            font-weight: 700;
        }

        .receipt-items {
            width: 100%;
            margin: 15px 0;
            font-size: 12px;
        }

        .receipt-items td {
            padding: 7px 0
        }

        .receipt-total {
            border-top: 1px dashed #d9c9bb;
            padding-top: 12px;
        }

        @media print {
            body * {
                visibility: hidden
            }

            #receiptContent,
            #receiptContent * {
                visibility: visible
            }

            #receiptContent {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                border: 0;
            }

            .modal-header,
            .modal-footer {
                display: none !important
            }
        }

        @media(max-width:991px) {
            .sidebar {
                transform: translateX(-100%)
            }

            .sidebar.show {
                transform: translateX(0)
            }

            .sidebar-overlay.show {
                display: block
            }

            .main-content {
                margin-left: 0;
                padding: 20px
            }

            .mobile-toggle {
                display: inline-block
            }
        }

        @media(max-width:576px) {
            .main-content {
                padding: 17px 13px
            }

            .page-title {
                font-size: 22px
            }

            .topbar-right {
                gap: 8px
            }

            .profile-info {
                display: none
            }

            .card-header-custom {
                align-items: stretch
            }

            .search-box {
                width: 100%
            }
        }
    </style>
</head>

<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <aside class="sidebar" id="sidebar">
        <div class="brand">
            <div class="brand-icon">
                <img src="../assets/logo.png" alt="Crumb & Co. Logo">
            </div>

            <div>
                <h5>Sweet Crumb</h5>
                <small>Bakery Management</small>
            </div>
        </div>

        <div class="menu-label">MAIN MENU</div>
        <nav class="nav flex-column">
            <a href="dashboard.php" class="nav-link"><i class="bi bi-grid-fill"></i> Dashboard</a>
            <a href="pos.php" class="nav-link"><i class="bi bi-cart3"></i> POS / New Sale</a>
        </nav>

        <div class="menu-label">MANAGEMENT</div>
        <nav class="nav flex-column">
            <a href="products.php" class="nav-link"><i class="bi bi-box-seam"></i> Products</a>
            <a href="categories.php" class="nav-link"><i class="bi bi-tags"></i> Categories</a>
            <a href="inventory.php" class="nav-link"><i class="bi bi-clipboard-data"></i> Inventory</a>
            <a href="stock-movements.php" class="nav-link"><i class="bi bi-arrow-left-right"></i> Stock Movements</a>
        </nav>

        <div class="menu-label">SALES & REPORTS</div>
        <nav class="nav flex-column">
            <a href="sales.php" class="nav-link active"><i class="bi bi-receipt"></i> Sales History</a>
            <a href="reports.php" class="nav-link"><i class="bi bi-bar-chart-line"></i> Reports</a>
        </nav>

        <div class="menu-label">SYSTEM</div>
        <nav class="nav flex-column">
            <a href="settings.php" class="nav-link"><i class="bi bi-gear"></i> Settings</a>
            <a href="logout.php" class="nav-link"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </nav>
    </aside>
    <main class="main-content">

        <div class="topbar">
            <div class="d-flex align-items-center gap-3">
                <button class="mobile-toggle" id="menuToggle">
                    <i class="bi bi-list"></i>
                </button>
                <div>
                    <h1 class="page-title">Sales History</h1>
                    <div class="page-subtitle">Track and review all bakery transactions.</div>
                </div>
            </div>
        </div>

        <div class="row g-3 mb-4">

            <div class="col-6 col-xl-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#eaf2fb;color:#5484b5;">
                        <i class="bi bi-receipt"></i>
                    </div>
                    <div class="stat-label">Total Transactions</div>
                    <div class="stat-value" id="totalTransactions">6</div>
                </div>
            </div>

            <div class="col-6 col-xl-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#e7f3eb;color:var(--success);">
                        <i class="bi bi-cash-stack"></i>
                    </div>
                    <div class="stat-label">Total Sales</div>
                    <div class="stat-value" id="totalSales">₱2,240</div>
                </div>
            </div>

            <div class="col-6 col-xl-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#fff3df;color:var(--warning);">
                        <i class="bi bi-wallet2"></i>
                    </div>
                    <div class="stat-label">Average Transaction</div>
                    <div class="stat-value" id="averageSale">₱373.33</div>
                </div>
            </div>

            <div class="col-6 col-xl-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#fbeae7;color:var(--danger);">
                        <i class="bi bi-hourglass-split"></i>
                    </div>
                    <div class="stat-label">Pending Payments</div>
                    <div class="stat-value" id="pendingPayments">1</div>
                </div>
            </div>

        </div>

        <div class="content-card">

            <div class="card-header-custom">
                <div>
                    <h6>Transaction History</h6>
                    <small class="text-muted-custom">List of recorded bakery sales.</small>
                </div>
            </div>

            <div class="p-3 d-flex flex-wrap gap-2 justify-content-between">

                <div class="search-box">
                    <i class="bi bi-search"></i>
                    <input type="text" class="form-control" id="searchInput" placeholder="Search receipt or customer...">
                </div>

                <div class="d-flex gap-2 flex-wrap">
                    <select class="form-select" id="paymentFilter" style="width:145px;">
                        <option value="all">All Payments</option>
                        <option value="Cash">Cash</option>
                        <option value="Gcash">GCash</option>
                    </select>

                    <input type="date" class="form-control" id="dateFilter" style="width:155px;">

                    <button type="button" class="btn btn-primary-custom" onclick="exportExcel()">
                        <i class="bi bi-file-earmark-excel me-1"></i>
                        Export Excel
                    </button>
                </div>

            </div>

            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Receipt No.</th>
                            <th>Date & Time</th>
                            <th>Customer</th>
                            <th>Items</th>
                            <th>Payment Method</th>
                            <th>Total Amount</th>
                            <th>Status</th>
                            <th>Cashier</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody id="salesBody">

                        <?php if ($sales && $sales->num_rows > 0): ?>

                            <?php while ($sale = $sales->fetch_assoc()): ?>

                                <?php
                                $sale_id = (int) $sale['sale_id'];

                                $item_stmt->bind_param("i", $sale_id);
                                $item_stmt->execute();

                                $item_result = $item_stmt->get_result();
                                $sale_items = $item_result->fetch_all(MYSQLI_ASSOC);

                                $payment = $sale['payment_method'];
                                $status = $sale['status'];

                                $status_class = 'badge-pending';

                                if (in_array($status, ['Completed', 'Paid'])) {
                                    $status_class = 'badge-paid';
                                } elseif ($status === 'Cancelled') {
                                    $status_class = 'badge-cancelled';
                                }

                                $cashier = $sale['cashier_name'] ?: 'Admin';

                                $date = date('M d, Y', strtotime($sale['created_at']));
                                $time = date('h:i A', strtotime($sale['created_at']));
                                ?>

                                <tr
                                    data-payment="<?= htmlspecialchars($payment) ?>"
                                    data-status="<?= htmlspecialchars($status) ?>"
                                    data-date="<?= date('Y-m-d', strtotime($sale['created_at'])) ?>"
                                    data-amount="<?= (float) $sale['total_amount'] ?>">

                                    <td>
                                        <strong>
                                            <?= htmlspecialchars($sale['receipt_number']) ?>
                                        </strong>
                                    </td>

                                    <td>
                                        <?= $date ?>
                                        <small class="d-block text-muted-custom">
                                            <?= $time ?>
                                        </small>
                                    </td>

                                    <td>Walk-in Customer</td>

                                    <td>
                                        <?= (int) $sale['item_count'] ?> items
                                    </td>

                                    <td>
                                        <span class="badge-payment">
                                            <?= htmlspecialchars($payment) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <strong>
                                            ₱<?= number_format((float) $sale['total_amount'], 2) ?>
                                        </strong>
                                    </td>

                                    <td>
                                        <span class="badge-status <?= $status_class ?>">
                                            <?= htmlspecialchars($status) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <?= htmlspecialchars($cashier) ?>
                                    </td>

                                    <td>
                                        <button
                                            class="action-btn"
                                            onclick="viewSale(this)"
                                            data-receipt="<?= htmlspecialchars($sale['receipt_number'], ENT_QUOTES, 'UTF-8') ?>"
                                            data-date="<?= htmlspecialchars($date . ' ' . $time, ENT_QUOTES, 'UTF-8') ?>"
                                            data-payment="<?= htmlspecialchars($payment, ENT_QUOTES, 'UTF-8') ?>"
                                            data-status="<?= htmlspecialchars($status, ENT_QUOTES, 'UTF-8') ?>"
                                            data-total="<?= (float) $sale['total_amount'] ?>"
                                            data-items="<?= htmlspecialchars(json_encode($sale_items), ENT_QUOTES, 'UTF-8') ?>">

                                            <i class="bi bi-eye"></i>
                                        </button>
                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <tr>
                                <td colspan="9" class="text-center py-4 text-muted">
                                    No sales transactions found.
                                </td>
                            </tr>

                        <?php endif; ?>

                    </tbody>
                </table>
            </div>

            <div class="p-3 border-top" style="border-color:var(--border)!important;">
                <small class="text-muted-custom" id="resultCount">Showing 6 transactions</small>
            </div>

        </div>

    </main>

    <!-- VIEW SALE MODAL -->
    <div class="modal fade" id="viewSaleModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title">Sale Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <div class="receipt" id="receiptContent">

                        <div class="receipt-header">
                            <h4>Sweet Crumb</h4>
                            <small>Bakery Sales & Inventory System</small>
                            <div class="mt-2 small">Official Sales Receipt</div>
                        </div>

                        <div class="d-flex justify-content-between mt-3 small">
                            <span>Receipt No.</span>
                            <strong id="receiptNumber">-</strong>
                        </div>

                        <div class="d-flex justify-content-between mt-2 small">
                            <span>Date</span>
                            <strong id="receiptDate">-</strong>
                        </div>

                        <div class="d-flex justify-content-between mt-2 small">
                            <span>Customer</span>
                            <strong id="receiptCustomer">-</strong>
                        </div>

                        <table class="receipt-items">
                            <thead>
                                <tr style="border-bottom:1px solid #eee;">
                                    <th class="py-2">Item</th>
                                    <th class="text-center">Qty</th>
                                    <th class="text-end">Amount</th>
                                </tr>
                            </thead>
                            <tbody id="receiptItems">
                                <tr>
                                    <td>Sample Bread</td>
                                    <td class="text-center">1</td>
                                    <td class="text-end">₱50.00</td>
                                </tr>
                            </tbody>
                        </table>

                        <div class="receipt-total">
                            <div class="d-flex justify-content-between fw-bold">
                                <span>Total</span>
                                <span id="receiptTotal">₱0.00</span>
                            </div>

                            <div class="d-flex justify-content-between small mt-2">
                                <span>Payment Method</span>
                                <span id="receiptPayment">-</span>
                            </div>

                            <div class="d-flex justify-content-between small mt-2">
                                <span>Status</span>
                                <span id="receiptStatus">-</span>
                            </div>
                        </div>

                        <div class="text-center mt-4 small">
                            Thank you for visiting Sweet Crumb!<br>
                            Freshly baked, made with love.
                        </div>

                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary-custom" onclick="window.print()">
                        <i class="bi bi-printer me-1"></i> Print Receipt
                    </button>
                </div>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        const menuToggle = document.getElementById('menuToggle');

        function toggleSidebar() {
            sidebar.classList.toggle('show');
            overlay.classList.toggle('show');
        }

        menuToggle.addEventListener('click', toggleSidebar);
        overlay.addEventListener('click', toggleSidebar);

        const searchInput = document.getElementById('searchInput');
        const paymentFilter = document.getElementById('paymentFilter');
        const dateFilter = document.getElementById('dateFilter');
        const salesBody = document.getElementById('salesBody');

        const today = new Date();
        const phDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000)
            .toISOString()
            .split('T')[0];

        dateFilter.value = phDate;

        function filterSales() {

            const search = searchInput.value.toLowerCase();
            const payment = paymentFilter.value;
            const date = dateFilter.value;

            const rows = salesBody.querySelectorAll('tr[data-amount]');
            let visible = 0;

            rows.forEach(row => {

                const text = row.textContent.toLowerCase();

                const matchesSearch = text.includes(search);
                const matchesPayment = payment === 'all' || row.dataset.payment === payment;
                const matchesDate = !date || row.dataset.date === date;

                const show = matchesSearch && matchesPayment && matchesDate;

                row.style.display = show ? '' : 'none';

                if (show) visible++;

            });

            document.getElementById('resultCount').textContent =
                `Showing ${visible} transaction${visible !== 1 ? 's' : ''}`;
        }

        searchInput.addEventListener('input', filterSales);
        paymentFilter.addEventListener('change', filterSales);
        dateFilter.addEventListener('change', function() {
            filterSales();
            updateSummary();
        });

        function viewSale(button) {

            const receiptNumber = button.dataset.receipt;
            const date = button.dataset.date;
            const payment = button.dataset.payment;
            const status = button.dataset.status;
            const total = Number(button.dataset.total);

            const items = JSON.parse(button.dataset.items);

            document.getElementById('receiptNumber').textContent = receiptNumber;
            document.getElementById('receiptDate').textContent = date;
            document.getElementById('receiptCustomer').textContent = 'Walk-in Customer';
            document.getElementById('receiptPayment').textContent = payment;
            document.getElementById('receiptStatus').textContent = status;
            document.getElementById('receiptTotal').textContent = money(total);

            let itemsHTML = '';

            items.forEach(item => {

                itemsHTML += `
            <tr>
                <td>
                    ${escapeHtml(item.product_name || 'Deleted Product')}
                    <small class="d-block text-muted">
                        ${money(Number(item.unit_price))} each
                    </small>
                </td>

                <td class="text-center">
                    ${Number(item.quantity)}
                </td>

                <td class="text-end">
                    ${money(Number(item.subtotal))}
                </td>
            </tr>
        `;

            });

            document.getElementById('receiptItems').innerHTML =
                itemsHTML || `
            <tr>
                <td colspan="3" class="text-center text-muted">
                    No items found.
                </td>
            </tr>
        `;

            new bootstrap.Modal(
                document.getElementById('viewSaleModal')
            ).show();

        }

        function updateSummary() {

            const rows = salesBody.querySelectorAll('tr[data-amount]');
            const selectedDate = dateFilter.value;

            let totalSales = 0;
            let totalTransactions = 0;
            let paidTransactions = 0;
            let pendingTransactions = 0;

            rows.forEach(row => {

                const matchesDate = !selectedDate || row.dataset.date === selectedDate;

                if (!matchesDate) return;

                totalTransactions++;

                const status = row.dataset.status;
                const amount = parseFloat(row.dataset.amount) || 0;

                if (status === 'Completed' || status === 'Paid') {
                    totalSales += amount;
                    paidTransactions++;
                }

                if (status === 'Pending') {
                    pendingTransactions++;
                }

            });

            const average = paidTransactions > 0 ?
                totalSales / paidTransactions :
                0;

            document.getElementById('totalTransactions').textContent = totalTransactions;

            document.getElementById('totalSales').textContent =
                money(totalSales);

            document.getElementById('averageSale').textContent =
                money(average);

            document.getElementById('pendingPayments').textContent =
                pendingTransactions;
        }

        updateSummary();
        filterSales();

        function money(amount) {
            return '₱' + amount.toLocaleString('en-PH', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }

        function escapeHtml(value) {
            return String(value).replace(/[&<>"']/g, character => ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            })[character]);
        }

        function exportExcel() {

            const rows = salesBody.querySelectorAll('tr[data-amount]');

            let csv = [];
            csv.push([
                'Receipt No.',
                'Date & Time',
                'Customer',
                'Items',
                'Payment Method',
                'Total Amount',
                'Status',
                'Cashier'
            ]);

            let exportedCount = 0;

            rows.forEach(row => {
                if (row.style.display === 'none') return;

                const cells = row.querySelectorAll('td');

                const rowData = [
                    cells[0].innerText.trim(),
                    cells[1].innerText.trim().replace(/\n/g, ' '),
                    cells[2].innerText.trim(),
                    cells[3].innerText.trim(),
                    cells[4].innerText.trim(),
                    cells[5].innerText.trim().replace('₱', '').replace(/,/g, ''),
                    cells[6].innerText.trim(),
                    cells[7].innerText.trim()
                ];

                csv.push(rowData);
                exportedCount++;

            });

            if (exportedCount === 0) {
                alert('No transactions available to export.');
                return;
            }

            const csvContent = csv.map(row =>
                row.map(value =>
                    '"' + String(value).replace(/"/g, '""') + '"'
                ).join(',')
            ).join('\r\n');

            const blob = new Blob(
                ['\uFEFF' + csvContent], {
                    type: 'text/csv;charset=utf-8;'
                }
            );

            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);

            link.setAttribute('href', url);
            link.setAttribute(
                'download',
                'Sweet_Crumb_Sales_' + (dateFilter.value || 'All_Dates') + '.csv'
            );

            document.body.appendChild(link);
            link.click();

            document.body.removeChild(link);
            URL.revokeObjectURL(url);

        }
    </script>

</body>

</html>