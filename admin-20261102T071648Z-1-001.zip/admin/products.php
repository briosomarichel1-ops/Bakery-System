<?php
session_start();
include "../conn.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$categories = [];
$categoryQuery = $conn->query("
    SELECT category_id, category_name
    FROM category
    ORDER BY category_name ASC
");

while ($category = $categoryQuery->fetch_assoc()) {
    $categories[] = $category;
}

$products = [];
$productQuery = $conn->query("
    SELECT 
        products.*,
        category.category_name
    FROM products
    LEFT JOIN category 
        ON products.category_id = category.category_id
    ORDER BY products.product_id DESC
");

while ($product = $productQuery->fetch_assoc()) {
    $products[] = $product;
}

$totalProducts = count($products);
$activeProducts = 0;
$lowStockProducts = 0;
$outOfStockProducts = 0;

foreach ($products as $product) {

    $stock = (int)$product['stock_quantity'];
    $limit = (int)$product['stock_limit'];

    if ($product['status'] === 'Active') {
        $activeProducts++;

        if ($stock <= 0) {
            $outOfStockProducts++;
        } elseif ($stock <= $limit) {
            $lowStockProducts++;
        }
    }
}

function e($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function getStockStatus($stock, $limit)
{
    if ($stock <= 0) return "Out of Stock";
    if ($stock <= $limit) return "Low Stock";
    return "In Stock";
}

function getStockClassPHP($stock, $limit)
{
    if ($stock <= 0) return "status-out";
    if ($stock <= $limit) return "status-low";
    return "status-stock";
}

function getStatusClassPHP($status)
{
    return $status === "Active" ? "status-stock" : "status-inactive";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products | Bakery Sales & Inventory</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        :root {
            --brown: #5b3828;
            --brown-dark: #4c2c20;
            --cream: #faf7f2;
            --beige: #eee5d9;
            --gold: #d8894c;
            --text: #332820;
            --muted: #8b8178;
            --border: #eee8e1;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: var(--cream);
            color: var(--text);
            font-family: 'DM Sans', sans-serif;
        }

        /* SIDEBAR - EXACTLY SAME AS DASHBOARD.PHP */

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 255px;
            height: 100vh;
            background: #4c2c20;
            color: white;
            padding: 25px 18px;
            z-index: 1050;
            transition: transform .3s ease;
            overflow-y: auto;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0 10px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, .12);
            margin-bottom: 25px;
        }

        .brand-icon {
            width: 75px;
            height: 75px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            background: transparent;
        }

        .brand-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            filter:
                drop-shadow(1px 0 0 white) drop-shadow(-1px 0 0 white) drop-shadow(0 1px 0 white) drop-shadow(0 -1px 0 white);
        }

        .brand h5 {
            font-family: 'Playfair Display', serif;
            font-size: 20px;
            margin: 0;
            color: white;
        }

        .brand small {
            color: #c6afa0;
            font-size: 11px;
        }

        .menu-label {
            color: #aa9586;
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 1.3px;
            padding: 0 12px;
            margin: 23px 0 10px;
        }

        .sidebar .nav-link {
            display: flex;
            align-items: center;
            gap: 13px;
            color: #d9c8bd;
            padding: 11px 13px;
            border-radius: 9px;
            font-size: 13px;
            font-weight: 500;
            margin-bottom: 5px;
            text-decoration: none;
            transition: .2s;
        }

        .sidebar .nav-link i {
            font-size: 17px;
        }

        .sidebar .nav-link:hover {
            background: rgba(255, 255, 255, .09);
            color: white;
        }

        .sidebar .nav-link.active {
            background: #d8894c;
            color: white;
            font-weight: 700;
        }

        .sidebar-footer {
            border-top: 1px solid rgba(255, 255, 255, .12);
            margin-top: 35px;
            padding: 20px 10px 0;
            color: #c6afa0;
            font-size: 11px;
        }

        /* MAIN CONTENT */

        .main {
            margin-left: 255px;
            min-height: 100vh;
        }

        .topbar {
            height: 75px;
            background: white;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 30px;
            margin-bottom: 0;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .topbar small {
            color: var(--muted);
        }

        .profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .profile-avatar {
            width: 38px;
            height: 38px;
            background: var(--beige);
            color: var(--brown);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
        }

        .content {
            padding: 25px 30px;
        }

        .page-title {
            font-family: 'Playfair Display', serif;
            font-size: 29px;
            font-weight: 700;
        }

        .page-subtitle {
            color: var(--muted);
            font-size: 13px;
        }

        .btn-brown {
            background: var(--brown);
            color: white;
            border: 1px solid var(--brown);
            border-radius: 8px;
            padding: 10px 16px;
            font-size: 13px;
            font-weight: 600;
        }

        .btn-brown:hover {
            background: var(--brown-dark);
            color: white;
        }

        .btn-outline-brown {
            border: 1px solid #d8c8b8;
            color: var(--brown);
            background: white;
            border-radius: 8px;
            font-size: 13px;
        }

        .btn-outline-brown:hover {
            background: var(--beige);
            color: var(--brown);
        }

        .stat-card {
            background: white;
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 19px;
            height: 100%;
        }

        .stat-icon {
            width: 39px;
            height: 39px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            margin-bottom: 13px;
        }

        .stat-card h4 {
            font-size: 23px;
            font-weight: 700;
            margin: 0;
        }

        .stat-card p {
            font-size: 12px;
            color: var(--muted);
            margin: 5px 0 0;
        }

        .panel {
            background: white;
            border: 1px solid var(--border);
            border-radius: 12px;
        }

        .panel-header {
            padding: 19px 22px;
            border-bottom: 1px solid var(--border);
        }

        .panel-header h6 {
            margin: 0;
            font-weight: 700;
            font-size: 15px;
        }

        .panel-body {
            padding: 20px 22px;
        }

        .form-control,
        .form-select {
            border: 1px solid #e8e0d7;
            border-radius: 8px;
            font-size: 13px;
            padding: 10px 12px;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: var(--gold);
            box-shadow: 0 0 0 3px rgba(216, 137, 76, .12);
        }

        .search-box {
            position: relative;
        }

        .search-box i {
            position: absolute;
            left: 13px;
            top: 11px;
            color: var(--muted);
        }

        .search-box input {
            padding-left: 38px;
        }

        .category-filter {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .category-btn {
            border: 1px solid #e8e0d7;
            background: white;
            color: #76685e;
            border-radius: 20px;
            padding: 7px 14px;
            font-size: 12px;
        }

        .category-btn.active {
            background: var(--brown);
            border-color: var(--brown);
            color: white;
        }

        .product-table {
            margin: 0;
        }

        .product-table th {
            background: #fcfaf7;
            color: #8b8178;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: .7px;
            font-weight: 700;
            padding: 14px 18px;
            border-bottom: 1px solid var(--border);
            white-space: nowrap;
        }

        .product-table td {
            padding: 14px 18px;
            vertical-align: middle;
            font-size: 13px;
            border-bottom: 1px solid #f3eee8;
        }

        .product-info {
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 190px;
        }

        .product-image {
            width: 48px;
            height: 48px;
            background: #f5eee5;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 25px;
            flex-shrink: 0;
            overflow: hidden;
        }

        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .product-name {
            font-weight: 700;
        }

        .product-code {
            font-size: 11px;
            color: var(--muted);
            margin-top: 3px;
        }

        .status {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 700;
            white-space: nowrap;
        }

        .status-stock {
            background: #e8f5ec;
            color: #32834b;
        }

        .status-low {
            background: #fff3dc;
            color: #ad781b;
        }

        .status-out {
            background: #fdeaea;
            color: #c34d4d;
        }

        .status-inactive {
            background: #efefef;
            color: #777;
        }

        .action-btn {
            width: 31px;
            height: 31px;
            border: 1px solid var(--border);
            background: white;
            border-radius: 7px;
            color: #77685d;
        }

        .action-btn:hover {
            background: var(--beige);
            color: var(--brown);
        }

        .modal-content {
            border: 0;
            border-radius: 14px;
        }

        .modal-header {
            padding: 20px 24px;
            border-bottom: 1px solid var(--border);
        }

        .modal-body {
            padding: 22px 24px;
        }

        .modal-footer {
            padding: 16px 24px;
            border-top: 1px solid var(--border);
        }

        .form-label {
            font-size: 12px;
            font-weight: 700;
            margin-bottom: 7px;
        }

        .required {
            color: #c34d4d;
        }

        .mobile-toggle {
            display: none;
            border: 0;
            background: transparent;
            font-size: 23px;
            color: var(--brown);
        }

        .overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, .4);
            z-index: 1040;
        }

        @media(max-width: 991px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.show {
                transform: translateX(0);
            }

            .overlay.show {
                display: block;
            }

            .main {
                margin-left: 0;
            }

            .mobile-toggle {
                display: block;
            }

            .content {
                padding: 25px 20px;
            }

            .topbar {
                padding: 0 20px;
            }
        }

        @media(max-width: 576px) {
            .page-title {
                font-size: 24px;
            }

            .content {
                padding: 17px 13px;
            }

            .topbar {
                height: 65px;
                padding: 0 14px;
            }

            .profile-info {
                display: none;
            }

            .panel-body {
                padding: 15px;
            }
        }
    </style>
</head>

<body>
    <div class="overlay" id="overlay" onclick="toggleSidebar()"></div>
    <aside class="sidebar" id="sidebar">
        <div class="brand">
            <div class="brand-icon">
                <img src="../assets/logo.png" alt="Crumb & Co. Logo">
            </div>

            <div>
                <h5>Sweet Crumb</h5>
                <small>Bakery Management</small>
            </div>
        </div>
        <div class="menu-label">MAIN MENU</div>
        <nav class="nav flex-column">
            <a href="dashboard.php" class="nav-link">
                <i class="bi bi-grid-fill"></i>
                Dashboard
            </a>

            <a href="pos.php" class="nav-link">
                <i class="bi bi-cart3"></i>
                POS / New Sale
            </a>
        </nav>

        <div class="menu-label">MANAGEMENT</div>

        <nav class="nav flex-column">
            <a href="products.php" class="nav-link active">
                <i class="bi bi-box-seam"></i>
                Products
            </a>

            <a href="categories.php" class="nav-link">
                <i class="bi bi-tags"></i>
                Categories
            </a>

            <a href="inventory.php" class="nav-link">
                <i class="bi bi-clipboard-data"></i>
                Inventory
            </a>

            <a href="stock-movements.php" class="nav-link">
                <i class="bi bi-arrow-left-right"></i>
                Stock Movements
            </a>
        </nav>

        <div class="menu-label">SALES & REPORTS</div>

        <nav class="nav flex-column">
            <a href="sales.php" class="nav-link">
                <i class="bi bi-receipt"></i>
                Sales History
            </a>

            <a href="reports.php" class="nav-link">
                <i class="bi bi-bar-chart-line"></i>
                Reports
            </a>
        </nav>

        <div class="menu-label">SYSTEM</div>

        <nav class="nav flex-column">
            <a href="settings.php" class="nav-link">
                <i class="bi bi-gear"></i>
                Settings
            </a>

            <a href="logout.php" class="nav-link">
                <i class="bi bi-box-arrow-right"></i>
                Logout
            </a>
        </nav>
    </aside>
    <main class="main">
        <header class="topbar">
            <div class="topbar-left">
                <button class="mobile-toggle" onclick="toggleSidebar()">
                    <i class="bi bi-list"></i>
                </button>

                <div>
                    <div class="fw-bold" style="font-size:14px;">Products</div>
                    <small>Manage your bakery products</small>
                </div>
            </div>
        </header>

        <div class="content">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">

                <div>
                    <h2 class="page-title mb-1">Products</h2>
                    <p class="page-subtitle mb-0">
                        Manage your bakery's product catalog and pricing.
                    </p>
                </div>

                <button class="btn btn-brown" data-bs-toggle="modal" data-bs-target="#addProductModal">
                    <i class="bi bi-plus-lg me-1"></i>
                    Add Product
                </button>

            </div>
            <div class="row g-3 mb-4">

                <div class="col-6 col-lg-3">
                    <div class="stat-card">
                        <div class="stat-icon" style="background:#f3e8dc;color:#8b5e3c;">
                            <i class="bi bi-box-seam"></i>
                        </div>
                        <h4 id="totalProducts"><?= $totalProducts ?></h4>
                        <p>Total Products</p>
                    </div>
                </div>

                <div class="col-6 col-lg-3">
                    <div class="stat-card">
                        <div class="stat-icon" style="background:#e8f5ec;color:#32834b;">
                            <i class="bi bi-check-circle"></i>
                        </div>
                        <h4 id="activeProducts"><?= $activeProducts ?></h4>
                        <p>Active Products</p>
                    </div>
                </div>

                <div class="col-6 col-lg-3">
                    <div class="stat-card">
                        <div class="stat-icon" style="background:#fff3dc;color:#ad781b;">
                            <i class="bi bi-exclamation-triangle"></i>
                        </div>
                        <h4 id="lowStockProducts"><?= $lowStockProducts ?></h4>
                        <p>Low Stock Products</p>
                    </div>
                </div>

                <div class="col-6 col-lg-3">
                    <div class="stat-card">
                        <div class="stat-icon" style="background:#fdeaea;color:#c34d4d;">
                            <i class="bi bi-x-circle"></i>
                        </div>
                        <h4 id="outOfStockProducts"><?= $outOfStockProducts ?></h4>
                        <p>Out of Stock</p>
                    </div>
                </div>

            </div>
            <div class="panel">

                <div class="panel-header d-flex flex-wrap justify-content-between align-items-center gap-3">

                    <div>
                        <h6>Product List</h6>
                        <small class="text-secondary" style="font-size:11px;">
                            View and manage all bakery products
                        </small>
                    </div>

                    <button class="btn btn-outline-brown btn-sm" onclick="resetFilters()">
                        <i class="bi bi-arrow-counterclockwise me-1"></i>
                        Reset Filters
                    </button>

                </div>

                <div class="panel-body">
                    <div class="row g-3 mb-3">

                        <div class="col-md-5">
                            <div class="search-box">
                                <i class="bi bi-search"></i>
                                <input type="text" class="form-control" id="searchInput"
                                    placeholder="Search product name or code...">
                            </div>
                        </div>

                        <div class="col-md-3">
                            <select class="form-select" id="stockFilter">
                                <option value="">All Stock Status</option>
                                <option value="In Stock">In Stock</option>
                                <option value="Low Stock">Low Stock</option>
                                <option value="Out of Stock">Out of Stock</option>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <select class="form-select" id="statusFilter">
                                <option value="">All Product Status</option>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>

                    </div>

                    <div class="category-filter mb-4">

                        <button class="category-btn active" data-category="All">
                            All Products
                        </button>

                        <?php foreach ($categories as $category): ?>
                            <button class="category-btn"
                                data-category="<?= e($category['category_name']) ?>"
                                data-category-id="<?= (int)$category['category_id'] ?>">
                                <?= e($category['category_name']) ?>
                            </button>
                        <?php endforeach; ?>

                    </div>
                    <div class="table-responsive">

                        <table class="table product-table align-middle">

                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Category</th>
                                    <th>Price</th>
                                    <th>Stock</th>
                                    <th>Stock Status</th>
                                    <th>Status</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>

                            <tbody id="productTableBody">

                                <?php foreach ($products as $product): ?>

                                    <?php
                                    $stock = (int)$product['stock_quantity'];
                                    $limit = (int)$product['stock_limit'];

                                    $stockStatus = getStockStatus($stock, $limit);
                                    $stockClass = getStockClassPHP($stock, $limit);
                                    $statusClass = getStatusClassPHP($product['status']);

                                    $productCode = "PRD-" . str_pad($product['product_id'], 3, "0", STR_PAD_LEFT);
                                    ?>

                                    <tr
                                        data-id="<?= (int)$product['product_id'] ?>"
                                        data-name="<?= e($product['product_name']) ?>"
                                        data-code="<?= e($productCode) ?>"
                                        data-category="<?= e($product['category_name']) ?>"
                                        data-price="<?= e($product['price']) ?>"
                                        data-stock="<?= $stock ?>"
                                        data-limit="<?= $limit ?>"
                                        data-status="<?= e($product['status']) ?>"
                                        data-image="<?= e($product['product_image']) ?>"
                                        data-category-id="<?= (int)$product['category_id'] ?>">


                                        <td>
                                            <div class="product-info">

                                                <div class="product-image">
                                                    <?php if (!empty($product['product_image'])): ?>
                                                        <img src="<?= e($product['product_image']) ?>" alt="Product image">
                                                    <?php else: ?>
                                                        🥐
                                                    <?php endif; ?>
                                                </div>

                                                <div>
                                                    <div class="product-name">
                                                        <?= e($product['product_name']) ?>
                                                    </div>

                                                    <div class="product-code">
                                                        <?= e($productCode) ?>
                                                    </div>
                                                </div>

                                            </div>
                                        </td>

                                        <td><?= e($product['category_name']) ?></td>

                                        <td class="fw-bold">
                                            ₱<?= number_format((float)$product['price'], 2) ?>
                                        </td>

                                        <td><?= $stock ?> pcs</td>

                                        <td>
                                            <span class="status <?= $stockClass ?>">
                                                <?= $stockStatus ?>
                                            </span>
                                        </td>

                                        <td>
                                            <span class="status <?= $statusClass ?>">
                                                <?= e($product['status']) ?>
                                            </span>
                                        </td>

                                        <td class="text-center">
                                            <button class="action-btn" onclick="addStock(this)" title="Add Quantity">
                                                <i class="bi bi-plus-lg"></i>
                                            </button>

                                            <button class="action-btn" onclick="editProduct(this)" title="Edit">
                                                <i class="bi bi-pencil"></i>
                                            </button>

                                            <button class="action-btn" onclick="deleteProduct(this)" title="Delete">
                                                <i class="bi bi-trash"></i>
                                            </button>

                                            <button class="action-btn" onclick="stockOut(this)" title="Stock Out">
                                                <i class="bi bi-dash-lg"></i>
                                            </button>
                                        </td>

                                    </tr>

                                <?php endforeach; ?>

                            </tbody>

                        </table>

                    </div>

                    <div id="emptyMessage" class="text-center py-5 d-none">
                        <i class="bi bi-search fs-1 text-secondary"></i>
                        <p class="text-secondary mt-2 mb-0">No products found.</p>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-3 flex-wrap gap-2">
                        <small class="text-secondary" id="showingCount">Showing 6 products</small>
                    </div>

                </div>
            </div>

        </div>
    </main>

    <!-- ADD PRODUCT MODAL -->
    <div class="modal fade" id="addProductModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <form id="addProductForm" action="actions/crud_operations.php" method="POST" enctype="multipart/form-data">
                    <div class="modal-header">
                        <div>
                            <h5 class="modal-title fw-bold">Add New Product</h5>
                            <small class="text-secondary">Enter the product information below.</small>
                        </div>

                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <div class="modal-body">

                        <div class="row g-3">

                            <div class="col-md-6">
                                <label class="form-label">Product Name <span class="required">*</span></label>
                                <input type="text" class="form-control" id="addName" name="product_name" required
                                    placeholder="Enter product name">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Category <span class="required">*</span></label>
                                <select class="form-select" id="addCategory" name="category_id" required>
                                    <option value="">Select category</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?= (int)$category['category_id'] ?>">
                                            <?= e($category['category_name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-3">
                                <label class="form-label">Selling Price (₱) <span class="required">*</span></label>
                                <input type="number" class="form-control" id="addPrice" name="price"
                                    min="0.01" step="0.01" required>
                            </div>

                            <div class="col-md-3">
                                <label class="form-label">Stock Limit<span class="required">*</span></label>
                                <input type="number" class="form-control" id="" name="stock_limit"
                                    min="0" step="1" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Product Image</label>
                                <input type="file" class="form-control" id="addImage" name="product_image" accept="image/*">
                                <small class="text-secondary">Optional image upload.</small>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-brown px-3" data-bs-dismiss="modal">
                            Cancel
                        </button>

                        <button type="submit" name="save_product" class="btn btn-brown px-4">
                            Save Product
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- EDIT PRODUCT MODAL -->
    <div class="modal fade" id="editProductModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <form id="editProductForm" action="actions/crud_operations.php" method="POST" enctype="multipart/form-data">
                    <div class="modal-header">
                        <div>
                            <h5 class="modal-title fw-bold">Edit Product</h5>
                            <small class="text-secondary">Update the product information.</small>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <div class="modal-body">
                        <input type="hidden" id="editRowIndex" name="product_id">

                        <div class="row g-3">
                            <div class="col-md-8">
                                <label class="form-label">Product Name <span class="required">*</span></label>
                                <input type="text" class="form-control" id="editName" name="product_name" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Category <span class="required">*</span></label>
                                <select class="form-select" id="editCategory" name="category_id" required>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?= (int)$category['category_id'] ?>">
                                            <?= e($category['category_name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-3">
                                <label class="form-label">Selling Price (₱) <span class="required">*</span></label>
                                <input type="number" class="form-control" id="editPrice" name="price"
                                    min="0.01" step="0.01" required>
                            </div>

                            <div class="col-md-3">
                                <label class="form-label">Stock Limit <span class="required">*</span></label>
                                <input type="number" class="form-control" id="editStockLimit" name="stock_limit"
                                    min="0" step="1" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Product Image</label>
                                <input type="file" class="form-control" id="editImage" name="product_image" accept="image/*">
                                <small class="text-secondary">Leave empty to keep the current image.</small>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Product Status</label>
                                <select class="form-select" id="editStatus" name="status">
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-brown px-3" data-bs-dismiss="modal">
                            Cancel
                        </button>

                        <button type="submit" name="update_product" class="btn btn-brown px-4">
                            Update Product
                        </button>
                    </div>

                </form>

            </div>

        </div>

    </div>

    <!-- ADD STOCK MODAL -->
    <div class="modal fade" id="addStockModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <form action="actions/crud_operations.php" method="POST">

                    <div class="modal-header">
                        <div>
                            <h5 class="modal-title fw-bold">Add Stock Quantity</h5>
                            <small class="text-secondary">Add inventory to an existing product.</small>
                        </div>

                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <div class="modal-body">

                        <input type="hidden" id="stockProductId" name="product_id">

                        <div class="mb-3">
                            <label class="form-label">Product Name</label>
                            <input type="text" class="form-control" id="stockProductName" readonly>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Current Stock</label>
                            <input type="number" class="form-control" id="currentStock" readonly>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Quantity to Add <span class="required">*</span></label>
                            <input type="number" class="form-control" id="addQuantity"
                                name="quantity" min="1" step="1" required
                                placeholder="Enter quantity">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">New Stock</label>
                            <input type="number" class="form-control" id="newStock" readonly>
                        </div>

                        <div class="mb-0">
                            <label class="form-label">Remarks</label>
                            <textarea class="form-control" name="remarks" rows="3"
                                placeholder="Optional remarks..."></textarea>
                        </div>

                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-brown px-3"
                            data-bs-dismiss="modal">
                            Cancel
                        </button>

                        <button type="submit" name="add_stock" class="btn btn-brown px-4">
                            <i class="bi bi-plus-lg me-1"></i>
                            Add Quantity
                        </button>
                    </div>

                </form>

            </div>
        </div>
    </div>

    <!-- STOCK OUT MODAL -->
    <div class="modal fade" id="stockOutModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <form action="actions/crud_operations.php" method="POST">

                    <div class="modal-header">
                        <div>
                            <h5 class="modal-title fw-bold">Stock Out</h5>
                            <small class="text-secondary">Remove quantity from product inventory.</small>
                        </div>

                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <div class="modal-body">

                        <input type="hidden" id="outProductId" name="product_id">

                        <div class="mb-3">
                            <label class="form-label">Product Name</label>
                            <input type="text" class="form-control" id="outProductName" readonly>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Current Stock</label>
                            <input type="number" class="form-control" id="outCurrentStock" readonly>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Quantity to Remove <span class="required">*</span></label>
                            <input type="number" class="form-control" id="outQuantity"
                                name="quantity" min="1" step="1" required
                                placeholder="Enter quantity">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Remaining Stock</label>
                            <input type="number" class="form-control" id="outNewStock" readonly>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Reason <span class="required">*</span></label>
                            <select class="form-select" name="remarks" id="outRemarks" required>
                                <option value="">Select reason</option>
                                <option value="Damaged Product">Damaged Product</option>
                                <option value="Expired Product">Expired Product</option>
                                <option value="Spoiled Product">Spoiled Product</option>
                                <option value="Missing or Lost">Missing or Lost</option>
                                <option value="Staff Consumption">Staff Consumption</option>
                                <option value="Free Samples / Giveaways">Free Samples / Giveaways</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>

                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-brown px-3"
                            data-bs-dismiss="modal">
                            Cancel
                        </button>

                        <button type="submit" name="stock_out" class="btn btn-danger px-4">
                            <i class="bi bi-dash-lg me-1"></i>
                            Confirm Stock Out
                        </button>
                    </div>

                </form>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        let selectedCategory = "All";

        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('show');
            document.getElementById('overlay').classList.toggle('show');
        }

        function getStockStatus(stock, limit) {
            if (stock <= 0) return "Out of Stock";
            if (stock <= limit) return "Low Stock";
            return "In Stock";
        }

        function applyFilters() {

            const search = document.getElementById('searchInput').value.toLowerCase();
            const stockFilter = document.getElementById('stockFilter').value;
            const statusFilter = document.getElementById('statusFilter').value;

            const rows = [...document.querySelectorAll('#productTableBody tr')];

            let visible = 0;

            rows.forEach(row => {

                const name = row.dataset.name.toLowerCase();
                const code = row.dataset.code.toLowerCase();
                const category = row.dataset.category;
                const stockStatus = getStockStatus(
                    Number(row.dataset.stock),
                    Number(row.dataset.limit)
                );
                const status = row.dataset.status;

                const matchesSearch = name.includes(search) || code.includes(search);

                const matchesCategory =
                    selectedCategory === "All" || category === selectedCategory;

                const matchesStock = !stockFilter || stockStatus === stockFilter;

                const matchesStatus = !statusFilter || status === statusFilter;

                const show =
                    matchesSearch &&
                    matchesCategory &&
                    matchesStock &&
                    matchesStatus;

                row.style.display = show ? "" : "none";

                if (show) visible++;
            });

            document.getElementById('emptyMessage').classList.toggle('d-none', visible > 0);

            document.getElementById('showingCount').textContent =
                `Showing ${visible} product(s)`;
        }

        document.getElementById('searchInput').addEventListener('input', applyFilters);
        document.getElementById('stockFilter').addEventListener('change', applyFilters);
        document.getElementById('statusFilter').addEventListener('change', applyFilters);

        document.querySelectorAll('.category-btn').forEach(button => {

            button.addEventListener('click', function() {

                document.querySelectorAll('.category-btn').forEach(btn => {
                    btn.classList.remove('active');
                });

                this.classList.add('active');

                selectedCategory = this.dataset.category;

                applyFilters();
            });

        });

        function resetFilters() {

            document.getElementById('searchInput').value = "";
            document.getElementById('stockFilter').value = "";
            document.getElementById('statusFilter').value = "";

            selectedCategory = "All";

            document.querySelectorAll('.category-btn').forEach(btn => {
                btn.classList.toggle('active', btn.dataset.category === "All");
            });

            applyFilters();
        }

        document.getElementById('addProductModal').addEventListener('show.bs.modal', function() {

            document.getElementById('addCode').value = "Generated automatically after saving";

        });

        document.getElementById('addProductForm').addEventListener('submit', function(e) {

            const name = document.getElementById('addName').value.trim();
            const category = document.getElementById('addCategory').value;
            const price = Number(document.getElementById('addPrice').value);
            const stock = Number(document.getElementById('addStock').value);

            if (!name || !category || price <= 0 || stock < 0 || !Number.isInteger(stock)) {
                e.preventDefault();
                alert("Please enter valid product details.");
                return;
            }
        });

        function editProduct(button) {

            const row = button.closest('tr');

            document.getElementById('editRowIndex').value = row.dataset.id;
            document.getElementById('editName').value = row.dataset.name;
            document.getElementById('editCategory').value = row.dataset.categoryId;
            document.getElementById('editPrice').value = row.dataset.price;
            document.getElementById('editStockLimit').value = row.dataset.limit;
            document.getElementById('editStatus').value = row.dataset.status;

            document.getElementById('editImage').value = "";

            bootstrap.Modal.getOrCreateInstance(
                document.getElementById('editProductModal')
            ).show();
        }

        function addStock(button) {

            const row = button.closest('tr');

            const productId = row.dataset.id;
            const productName = row.dataset.name;
            const currentStock = Number(row.dataset.stock);

            document.getElementById('stockProductId').value = productId;
            document.getElementById('stockProductName').value = productName;
            document.getElementById('currentStock').value = currentStock;

            document.getElementById('addQuantity').value = "";
            document.getElementById('newStock').value = currentStock;

            bootstrap.Modal.getOrCreateInstance(
                document.getElementById('addStockModal')
            ).show();
        }

        function stockOut(button) {

            const row = button.closest('tr');

            const productId = row.dataset.id;
            const productName = row.dataset.name;
            const currentStock = Number(row.dataset.stock);

            document.getElementById('outProductId').value = productId;
            document.getElementById('outProductName').value = productName;
            document.getElementById('outCurrentStock').value = currentStock;

            document.getElementById('outQuantity').value = "";
            document.getElementById('outNewStock').value = currentStock;
            document.getElementById('outRemarks').value = "";

            document.getElementById('outQuantity').max = currentStock;

            bootstrap.Modal.getOrCreateInstance(
                document.getElementById('stockOutModal')
            ).show();
        }

        document.getElementById('outQuantity').addEventListener('input', function() {

            const currentStock = Number(document.getElementById('outCurrentStock').value);
            const quantity = Number(this.value);

            document.getElementById('outNewStock').value =
                currentStock - (quantity > 0 ? quantity : 0);

        });

        document.getElementById('addQuantity').addEventListener('input', function() {

            const currentStock = Number(document.getElementById('currentStock').value);
            const quantity = Number(this.value);

            document.getElementById('newStock').value =
                currentStock + (quantity > 0 ? quantity : 0);

        });

        document.getElementById('editProductForm').addEventListener('submit', function(e) {

            const name = document.getElementById('editName').value.trim();
            const category = document.getElementById('editCategory').value;
            const price = Number(document.getElementById('editPrice').value);
            const stock = Number(document.getElementById('editStock').value);

            if (!name || !category || price <= 0 || stock < 0 || !Number.isInteger(stock)) {
                e.preventDefault();
                alert("Please enter valid product details.");
            }
        });

        function deleteProduct(button) {

            const row = button.closest('tr');
            const productId = row.dataset.id;
            const productName = row.dataset.name;

            if (!confirm("Are you sure you want to delete " + productName + "?")) {
                return;
            }

            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'actions/crud_operations.php';

            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'product_id';
            idInput.value = productId;

            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'delete_product';
            actionInput.value = '1';

            form.appendChild(idInput);
            form.appendChild(actionInput);

            document.body.appendChild(form);
            form.submit();
        }
        applyFilters();
    </script>


    <?php if (isset($_SESSION['swal'])): ?>
        <script>
            Swal.fire({
                icon: <?= json_encode($_SESSION['swal']['icon']); ?>,
                title: <?= json_encode($_SESSION['swal']['title']); ?>,
                text: <?= json_encode($_SESSION['swal']['text']); ?>
            });
        </script>
    <?php
        unset($_SESSION['swal']);
    endif;
    ?>

</body>

</html>