<?php
session_start();
date_default_timezone_set('Asia/Manila');

include '../conn.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$conn->query("SET time_zone = '+08:00'");

$sales_query = "
    SELECT
        s.sale_id,
        s.receipt_number,
        s.total_amount,
        s.payment_method,
        s.status,
        s.created_at,
        si.product_id,
        si.quantity,
        si.subtotal,
        p.product_name
    FROM sales s
    LEFT JOIN sale_items si
        ON s.sale_id = si.sale_id
    LEFT JOIN products p
        ON si.product_id = p.product_id
    WHERE s.status IN ('Completed', 'Paid')
    ORDER BY s.created_at DESC
";

$sales_result = $conn->query($sales_query);

$sales_data = [];

if ($sales_result) {

    while ($row = $sales_result->fetch_assoc()) {

        $sale_id = $row['sale_id'];

        if (!isset($sales_data[$sale_id])) {

            $sales_data[$sale_id] = [
                'receipt_number' => $row['receipt_number'],
                'total_amount' => (float) $row['total_amount'],
                'payment_method' => $row['payment_method'],
                'created_at' => $row['created_at'],
                'date' => date('Y-m-d', strtotime($row['created_at'])),
                'items' => []
            ];
        }

        if ($row['product_id'] !== null) {

            $sales_data[$sale_id]['items'][] = [
                'product_name' => $row['product_name'] ?? 'Deleted Product',
                'quantity' => (int) $row['quantity'],
                'subtotal' => (float) $row['subtotal']
            ];
        }
    }
}

$sales_data = array_values($sales_data);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports | Bakery Sales & Inventory</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        :root {
            --primary: #75452e;
            --primary-dark: #4c2c20;
            --primary-light: #f4e9df;
            --accent: #d8894c;
            --background: #faf8f4;
            --white: #fff;
            --text: #332820;
            --muted: #95877d;
            --border: #eee7df;
            --success: #478765;
            --warning: #d99b38;
            --danger: #cf6656;
            --sidebar-width: 255px;
        }

        * {
            box-sizing: border-box
        }

        body {
            margin: 0;
            font-family: 'DM Sans', sans-serif;
            background: var(--background);
            color: var(--text);
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: var(--primary-dark);
            color: white;
            padding: 25px 18px;
            z-index: 1050;
            transition: transform .3s ease;
            overflow-y: auto;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0 10px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, .12);
            margin-bottom: 25px;
        }

        .brand-icon {
            width: 75px;
            height: 75px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            background: transparent;
        }

        .brand-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            filter:
                drop-shadow(1px 0 0 white) drop-shadow(-1px 0 0 white) drop-shadow(0 1px 0 white) drop-shadow(0 -1px 0 white);
        }

        .brand h5 {
            font-family: 'Playfair Display', serif;
            font-size: 20px;
            margin: 0;
        }

        .brand small {
            color: #c6afa0;
            font-size: 11px;
        }

        .menu-label {
            color: #aa9586;
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 1.3px;
            padding: 0 12px;
            margin: 23px 0 10px;
        }

        .sidebar .nav-link {
            display: flex;
            align-items: center;
            gap: 13px;
            color: #d9c8bd;
            padding: 11px 13px;
            border-radius: 9px;
            font-size: 13px;
            font-weight: 500;
            margin-bottom: 5px;
            transition: .2s;
        }

        .sidebar .nav-link i {
            font-size: 17px
        }

        .sidebar .nav-link:hover {
            background: rgba(255, 255, 255, .09);
            color: white;
        }

        .sidebar .nav-link.active {
            background: var(--accent);
            color: white;
            font-weight: 700;
        }

        .sidebar-footer {
            border-top: 1px solid rgba(255, 255, 255, .12);
            margin-top: 35px;
            padding: 20px 10px 0;
            color: #c6afa0;
            font-size: 11px;
        }

        .main-content {
            margin-left: var(--sidebar-width);
            padding: 25px 30px;
            min-height: 100vh;
        }

        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, .4);
            z-index: 1040;
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 30px;
            gap: 15px;
        }

        .page-title {
            font-family: 'Playfair Display', serif;
            font-size: 27px;
            font-weight: 700;
            margin: 0;
        }

        .page-subtitle {
            color: var(--muted);
            font-size: 12px;
            margin-top: 4px;
        }

        .mobile-toggle {
            display: none;
            border: 0;
            background: var(--white);
            padding: 8px 11px;
            border-radius: 8px;
            color: var(--text);
            font-size: 20px;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 18px;
        }

        .icon-button {
            width: 38px;
            height: 38px;
            border: 1px solid var(--border);
            background: white;
            border-radius: 10px;
            color: var(--text);
        }

        .profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .profile-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: var(--primary-light);
            color: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
        }

        .profile small {
            display: block;
            color: var(--muted);
            font-size: 11px;
        }

        .stat-card {
            background: white;
            border: 1px solid var(--border);
            border-radius: 13px;
            padding: 19px;
            height: 100%;
        }

        .stat-icon {
            width: 39px;
            height: 39px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 10px;
            font-size: 19px;
            margin-bottom: 13px;
        }

        .stat-label {
            color: var(--muted);
            font-size: 12px;
        }

        .stat-value {
            font-size: 25px;
            font-weight: 700;
            margin-top: 3px;
        }

        .content-card {
            background: white;
            border: 1px solid var(--border);
            border-radius: 13px;
            overflow: hidden;
            height: 100%;
        }

        .card-header-custom {
            padding: 19px 21px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }

        .card-header-custom h6 {
            font-weight: 700;
            margin: 0;
        }

        .card-body-custom {
            padding: 20px
        }

        .form-control,
        .form-select {
            border-color: var(--border);
            font-size: 13px;
            padding: 10px 12px;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(216, 137, 76, .12);
        }

        .btn-primary-custom {
            background: var(--primary);
            color: white;
            border: 0;
            border-radius: 8px;
            padding: 10px 16px;
            font-size: 13px;
            font-weight: 600;
        }

        .btn-primary-custom:hover {
            background: var(--primary-dark);
            color: white;
        }

        .text-muted-custom {
            color: var(--muted)
        }

        .chart-container {
            position: relative;
            height: 280px;
            width: 100%;
        }

        .top-product {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 14px 0;
            border-bottom: 1px solid #f2ede7;
            gap: 12px;
        }

        .top-product:last-child {
            border-bottom: 0
        }

        .product-rank {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 9px;
            background: var(--primary-light);
            color: var(--primary);
            font-weight: 700;
            font-size: 12px;
            flex-shrink: 0;
        }

        .product-info {
            flex: 1;
            min-width: 0;
        }

        .product-info strong {
            display: block;
            font-size: 12px;
        }

        .product-info small {
            color: var(--muted);
            font-size: 11px;
        }

        .product-sales {
            font-weight: 700;
            font-size: 12px;
            text-align: right;
        }

        .payment-row {
            margin-bottom: 20px
        }

        .payment-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 7px;
            font-size: 12px;
        }

        .progress {
            height: 9px;
            background: #f1ebe5;
            border-radius: 20px;
        }

        .progress-bar {
            border-radius: 20px;
            background: var(--primary);
        }

        .table {
            margin: 0;
            white-space: nowrap;
        }

        .table thead th {
            background: #fcfaf7;
            color: var(--muted);
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: .6px;
            padding: 14px 18px;
            border-bottom: 1px solid var(--border);
        }

        .table tbody td {
            padding: 14px 18px;
            font-size: 12px;
            vertical-align: middle;
            border-bottom: 1px solid #f2ede7;
        }

        @media print {
            body {
                background: white
            }

            .sidebar,
            .topbar-right,
            .mobile-toggle,
            .sidebar-overlay,
            .filter-section,
            .print-button {
                display: none !important
            }

            .main-content {
                margin: 0;
                padding: 0
            }

            .content-card,
            .stat-card {
                break-inside: avoid
            }
        }

        @media(max-width:991px) {
            .sidebar {
                transform: translateX(-100%)
            }

            .sidebar.show {
                transform: translateX(0)
            }

            .sidebar-overlay.show {
                display: block
            }

            .main-content {
                margin-left: 0;
                padding: 20px
            }

            .mobile-toggle {
                display: inline-block
            }
        }

        @media(max-width:576px) {
            .main-content {
                padding: 17px 13px
            }

            .page-title {
                font-size: 22px
            }

            .topbar-right {
                gap: 8px
            }

            .profile-info {
                display: none
            }
        }
    </style>
</head>

<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <aside class="sidebar" id="sidebar">
        <div class="brand">
            <div class="brand-icon">
                <img src="../assets/logo.png" alt="Crumb & Co. Logo">
            </div>

            <div>
                <h5>Sweet Crumb</h5>
                <small>Bakery Management</small>
            </div>
        </div>

        <div class="menu-label">MAIN MENU</div>
        <nav class="nav flex-column">
            <a href="dashboard.php" class="nav-link"><i class="bi bi-grid-fill"></i> Dashboard</a>
            <a href="pos.php" class="nav-link"><i class="bi bi-cart3"></i> POS / New Sale</a>
        </nav>

        <div class="menu-label">MANAGEMENT</div>
        <nav class="nav flex-column">
            <a href="products.php" class="nav-link"><i class="bi bi-box-seam"></i> Products</a>
            <a href="categories.php" class="nav-link"><i class="bi bi-tags"></i> Categories</a>
            <a href="inventory.php" class="nav-link"><i class="bi bi-clipboard-data"></i> Inventory</a>
            <a href="stock-movements.php" class="nav-link"><i class="bi bi-arrow-left-right"></i> Stock Movements</a>
        </nav>

        <div class="menu-label">SALES & REPORTS</div>
        <nav class="nav flex-column">
            <a href="sales.php" class="nav-link"><i class="bi bi-receipt"></i> Sales History</a>
            <a href="reports.php" class="nav-link active"><i class="bi bi-bar-chart-line"></i> Reports</a>
        </nav>

        <div class="menu-label">SYSTEM</div>
        <nav class="nav flex-column">
            <a href="settings.php" class="nav-link"><i class="bi bi-gear"></i> Settings</a>
            <a href="logout.php" class="nav-link"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </nav>
    </aside>

    <main class="main-content">

        <div class="topbar">
            <div class="d-flex align-items-center gap-3">
                <button class="mobile-toggle" id="menuToggle">
                    <i class="bi bi-list"></i>
                </button>
                <div>
                    <h1 class="page-title">Reports & Analytics</h1>
                    <div class="page-subtitle">Monitor your bakery's sales and business performance.</div>
                </div>
            </div>
        </div>

        <div class="content-card mb-4 filter-section">
            <div class="card-body-custom">
                <div class="row g-3 align-items-end">

                    <div class="col-md-4">
                        <label class="form-label fw-bold small">Start Date</label>
                        <input type="date" class="form-control" id="startDate" value="2026-10-01">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label fw-bold small">End Date</label>
                        <input type="date" class="form-control" id="endDate" value="2026-10-30">
                    </div>

                    <div class="col-md-4 d-flex gap-2">
                        <button class="btn btn-primary-custom flex-grow-1" id="applyFilter">
                            <i class="bi bi-funnel me-1"></i> Apply Filter
                        </button>
                    </div>

                </div>
            </div>
        </div>

        <div class="row g-3 mb-4">

            <div class="col-6 col-xl-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#e7f3eb;color:var(--success);">
                        <i class="bi bi-cash-stack"></i>
                    </div>
                    <div class="stat-label">Total Sales</div>
                    <div class="stat-value" id="totalSales">₱1,700</div>
                    <small class="text-muted-custom">Paid transactions</small>
                </div>
            </div>

            <div class="col-6 col-xl-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#eaf2fb;color:#5484b5;">
                        <i class="bi bi-receipt"></i>
                    </div>
                    <div class="stat-label">Transactions</div>
                    <div class="stat-value" id="totalTransactions">4</div>
                    <small class="text-muted-custom">Paid sales</small>
                </div>
            </div>

            <div class="col-6 col-xl-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#fff3df;color:var(--warning);">
                        <i class="bi bi-basket"></i>
                    </div>
                    <div class="stat-label">Products Sold</div>
                    <div class="stat-value" id="productsSold">29</div>
                    <small class="text-muted-custom">Total quantity sold</small>
                </div>
            </div>

            <div class="col-6 col-xl-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#f4e9df;color:var(--primary);">
                        <i class="bi bi-graph-up-arrow"></i>
                    </div>
                    <div class="stat-label">Average Sale</div>
                    <div class="stat-value" id="averageSale">₱425</div>
                    <small class="text-muted-custom">Per transaction</small>
                </div>
            </div>

        </div>

        <div class="row g-3 mb-4">

            <div class="col-lg-8">
                <div class="content-card">
                    <div class="card-header-custom">
                        <div>
                            <h6>Sales Overview</h6>
                            <small class="text-muted-custom">Daily sales performance</small>
                        </div>
                        <span class="text-muted-custom small" id="salesDateLabel">Today</span>
                    </div>

                    <div class="card-body-custom">
                        <div class="chart-container">
                            <canvas id="salesChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="content-card">
                    <div class="card-header-custom">
                        <div>
                            <h6>Payment Methods</h6>
                            <small class="text-muted-custom">Sales by payment type</small>
                        </div>
                    </div>

                    <div class="card-body-custom">
                        <div class="chart-container" style="height:220px;">
                            <canvas id="paymentChart"></canvas>
                        </div>

                        <div class="mt-4" id="paymentBreakdown">

                            <div class="payment-row">
                                <div class="payment-info">
                                    <span><i class="bi bi-circle-fill me-2" style="color:#75452e;font-size:9px;"></i>Cash</span>
                                    <strong>₱600.00</strong>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar" style="width:35.3%"></div>
                                </div>
                            </div>

                            <div class="payment-row">
                                <div class="payment-info">
                                    <span><i class="bi bi-circle-fill me-2" style="color:#d8894c;font-size:9px;"></i>GCash</span>
                                    <strong>₱480.00</strong>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar" style="width:28.2%;background:#d8894c;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="row g-3 mb-4">

            <div class="col-lg-5">
                <div class="content-card">
                    <div class="card-header-custom">
                        <div>
                            <h6>Top Selling Products</h6>
                            <small class="text-muted-custom">Best performing bakery products</small>
                        </div>
                    </div>

                    <div class="card-body-custom" id="topProducts">
                        <div class="text-center text-muted py-4">
                            Loading products...
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-7">
                <div class="content-card">
                    <div class="card-header-custom">
                        <div>
                            <h6>Recent Sales</h6>
                            <small class="text-muted-custom">Latest recorded transactions</small>
                        </div>
                        <a href="sales.php" class="small text-decoration-none" style="color:var(--primary);font-weight:700;">
                            View All <i class="bi bi-arrow-right"></i>
                        </a>
                    </div>

                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Receipt No.</th>
                                    <th>Date</th>
                                    <th>Payment</th>
                                    <th>Amount</th>
                                </tr>
                            </thead>

                            <tbody id="recentSales">
                                <tr>
                                    <td colspan="4" class="text-center text-muted py-4">
                                        Loading sales...
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>

        </div>

    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        const menuToggle = document.getElementById('menuToggle');

        function toggleSidebar() {
            sidebar.classList.toggle('show');
            overlay.classList.toggle('show');
        }

        menuToggle.addEventListener('click', toggleSidebar);
        overlay.addEventListener('click', toggleSidebar);

        const reportSales = <?= json_encode(
                                $sales_data,
                                JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
                            ) ?>;

        function money(amount) {
            return '₱' + Number(amount).toLocaleString('en-PH', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }

        function escapeHtml(value) {
            return String(value ?? '').replace(/[&<>"']/g, character => ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            })[character]);
        }

        const salesChart = new Chart(document.getElementById('salesChart'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Sales',
                    data: [],
                    borderColor: '#75452e',
                    backgroundColor: 'rgba(117,69,46,.10)',
                    fill: true,
                    tension: .4,
                    borderWidth: 2,
                    pointRadius: 4,
                    pointBackgroundColor: '#d8894c'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: context => ' ' + money(context.raw)
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: '#f1ebe5'
                        },
                        ticks: {
                            callback: value => '₱' + value.toLocaleString('en-PH')
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });

        const paymentChart = new Chart(document.getElementById('paymentChart'), {
            type: 'doughnut',
            data: {
                labels: ['Cash', 'GCash'],
                datasets: [{
                    data: [0, 0],
                    backgroundColor: ['#75452e', '#d8894c'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '70%',
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

        function applyReportFilter() {

            const start = document.getElementById('startDate').value;
            const end = document.getElementById('endDate').value;

            if (!start || !end) {
                alert('Please select both start and end dates.');
                return;
            }

            if (start > end) {
                alert('Start date cannot be later than end date.');
                return;
            }

            const filteredSales = reportSales.filter(sale =>
                sale.date >= start && sale.date <= end
            );

            let totalSales = 0;
            let totalProducts = 0;

            const productSummary = {};
            const paymentSummary = {};

            const dailySales = {};

            filteredSales.forEach(sale => {

                const amount = Number(sale.total_amount) || 0;

                totalSales += amount;

                const payment = sale.payment_method || 'Other';

                paymentSummary[payment] =
                    (paymentSummary[payment] || 0) + amount;

                dailySales[sale.date] =
                    (dailySales[sale.date] || 0) + amount;

                sale.items.forEach(item => {

                    const name = item.product_name || 'Deleted Product';
                    const quantity = Number(item.quantity) || 0;
                    const subtotal = Number(item.subtotal) || 0;

                    totalProducts += quantity;

                    if (!productSummary[name]) {
                        productSummary[name] = {
                            quantity: 0,
                            sales: 0
                        };
                    }

                    productSummary[name].quantity += quantity;
                    productSummary[name].sales += subtotal;

                });

            });

            const transactions = filteredSales.length;

            const average = transactions > 0 ?
                totalSales / transactions : 0;

            document.getElementById('totalSales').textContent =
                money(totalSales);

            document.getElementById('totalTransactions').textContent =
                transactions;

            document.getElementById('productsSold').textContent =
                totalProducts;

            document.getElementById('averageSale').textContent =
                money(average);

            const today = new Date().toLocaleDateString('en-CA', {
                timeZone: 'Asia/Manila'
            });

            document.getElementById('salesDateLabel').textContent =
                start === today && end === today ?
                'Today' :
                `${start} - ${end}`;

            const chartLabels = [];
            const chartValues = [];

            const startParts = start.split('-').map(Number);
            const endParts = end.split('-').map(Number);

            const currentDate = new Date(
                startParts[0],
                startParts[1] - 1,
                startParts[2]
            );

            const lastDate = new Date(
                endParts[0],
                endParts[1] - 1,
                endParts[2]
            );

            while (currentDate <= lastDate) {

                const year = currentDate.getFullYear();
                const month = String(currentDate.getMonth() + 1).padStart(2, '0');
                const day = String(currentDate.getDate()).padStart(2, '0');

                const dateKey = `${year}-${month}-${day}`;

                chartLabels.push(
                    currentDate.toLocaleDateString('en-PH', {
                        month: 'short',
                        day: 'numeric'
                    })
                );

                chartValues.push(dailySales[dateKey] || 0);

                currentDate.setDate(currentDate.getDate() + 1);
            }

            salesChart.data.labels = chartLabels;
            salesChart.data.datasets[0].data = chartValues;
            salesChart.update();

            // UPDATE PAYMENT CHART
            const paymentLabels = Object.keys(paymentSummary);
            const paymentValues = Object.values(paymentSummary);

            const paymentColors = paymentLabels.map(payment => {
                return payment.toLowerCase() === 'cash' ?
                    '#75452e' : '#d8894c';
            });

            paymentChart.data.labels = paymentLabels;
            paymentChart.data.datasets[0].data = paymentValues;
            paymentChart.data.datasets[0].backgroundColor = paymentColors;
            paymentChart.update();

            const paymentTotal = paymentValues.reduce(
                (sum, amount) => sum + amount, 0
            );

            document.getElementById('paymentBreakdown').innerHTML =

                paymentLabels.length > 0 ?

                paymentLabels.map((payment, index) => {

                    const amount = paymentValues[index];

                    const percentage = paymentTotal > 0 ?
                        (amount / paymentTotal) * 100 : 0;

                    const color = paymentColors[index];

                    return `
                <div class="payment-row">

                    <div class="payment-info">
                        <span>
                            <i class="bi bi-circle-fill me-2"
                               style="color:${color};font-size:9px;"></i>
                            ${escapeHtml(payment)}
                        </span>

                        <strong>${money(amount)}</strong>
                    </div>

                    <div class="progress">
                        <div class="progress-bar"
                             style="width:${percentage}%;background:${color};">
                        </div>
                    </div>

                </div>
            `;

                }).join('') :

                '<div class="text-center text-muted py-3">No payment records found.</div>';

            const topProducts = Object.entries(productSummary)
                .sort((a, b) => b[1].quantity - a[1].quantity)
                .slice(0, 5);

            document.getElementById('topProducts').innerHTML =

                topProducts.length > 0 ?

                topProducts.map(([name, data], index) => `

            <div class="top-product">

                <div class="d-flex align-items-center gap-3">

                    <div class="product-rank">
                        ${index + 1}
                    </div>

                    <div class="product-info">
                        <strong>${escapeHtml(name)}</strong>
                        <small>${data.quantity} pieces sold</small>
                    </div>

                </div>

                <div class="product-sales">
                    ${money(data.sales)}
                </div>

            </div>

        `).join('') :

                '<div class="text-center text-muted py-4">No products sold within this date range.</div>';

            const recentSales = [...filteredSales]
                .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
                .slice(0, 5);

            document.getElementById('recentSales').innerHTML =

                recentSales.length > 0 ?

                recentSales.map(sale => {

                    const date = new Date(
                        sale.created_at.replace(' ', 'T')
                    );

                    return `
                <tr>

                    <td>
                        <strong>${escapeHtml(sale.receipt_number)}</strong>
                    </td>

                    <td>
                        ${date.toLocaleDateString('en-PH', {
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric'
                        })}
                    </td>

                    <td>
                        ${escapeHtml(sale.payment_method)}
                    </td>

                    <td>
                        <strong>${money(sale.total_amount)}</strong>
                    </td>

                </tr>
            `;

                }).join('') :

                `
            <tr>
                <td colspan="4" class="text-center text-muted py-4">
                    No sales transactions found.
                </td>
            </tr>
        `;

        }

        document.getElementById('applyFilter').addEventListener(
            'click',
            applyReportFilter
        );

        applyReportFilter();
    </script>

</body>

</html>